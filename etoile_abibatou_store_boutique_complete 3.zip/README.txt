ÉTOILE ABIBATOU STORE — SITE BOUTIQUE V2

Contenu :
- accueil luxe blanc/noir/or
- catalogue et catégories
- tailles
- panier enregistré dans le navigateur
- commande WhatsApp
- assistant boutique de démonstration
- responsive mobile

Pour une vraie IA en production : connecter le formulaire de l'assistant à un backend sécurisé et à une API de modèle IA. Ne jamais mettre une clé API secrète directement dans index.html.

Pour personnaliser les articles, modifier la liste `products` dans index.html ou demander une version avec un espace administrateur.
